#!/bin/sh
set -e

git submodule init
git submodule update

npm publish
